package com.example.textmessageapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class MainActivity extends AppCompatActivity {

    private static final int permission_request_code=1;
    private EditText phoneNumberEditText,messageEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phoneNumberEditText= findViewById(R.id.editPhoneNumber);
        messageEditText= findViewById(R.id.editMessage);
        Button sendButton= findViewById(R.id.btnSend);

        sendButton.setOnClickListener(view -> sendSMS());
        requestSmsPermission();
    }
    private void requestSmsPermission() {
        ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, permission_request_code);
        }
    }
    private void sendSMS() {
        String phoneNumber=phoneNumberEditText.getText().toString();
        String textMessage=messageEditText.getText().toString();
        try {
            if(phoneNumber.length()==10 && textMessage.length()<=160) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, textMessage, null, null);
                Toast.makeText(this, " Text Message Sent Successfully", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Enter a valid phone number and message in max 160 characters",Toast.LENGTH_SHORT).show();
            }
        }
        catch(Exception exception ) {
               Toast.makeText(this, "Failed to Send Text Message", Toast.LENGTH_SHORT).show();
               exception.printStackTrace();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == permission_request_code) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
